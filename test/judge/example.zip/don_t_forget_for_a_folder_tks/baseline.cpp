#include <iostream>
using namespace std;

int main() {
    cout << "Goodbye DSA 2020" << endl;
    return 0;
}
